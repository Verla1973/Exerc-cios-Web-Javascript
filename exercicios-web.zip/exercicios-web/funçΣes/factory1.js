function criarPessoa() {
    return {
        nome: 'Ana',
        sobrenome: 'Tirza'
    }
}

console.log(criarPessoa())