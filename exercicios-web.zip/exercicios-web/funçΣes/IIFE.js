// IIFE => sigla de função auto invocada

(function() {
    console.log('Será executada na hora que a função for declarada...!')
    console.log('Foge do escopo mais abrangente(Global)')
})()