this.ola = 'Fala Pessoal'
exports.bemVindo = 'Bem vindo ao node'
module.exports.ateLogo = 'Até o próximo exemplo'