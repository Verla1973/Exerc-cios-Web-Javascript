const saudacoes = require('./passandoParametros')('Ana', 'Mano', 'Fernanda')
console.log(saudacoes)