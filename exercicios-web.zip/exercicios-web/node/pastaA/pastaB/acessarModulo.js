moduloA = require('../../moduloA')
console.log(moduloA.ola)