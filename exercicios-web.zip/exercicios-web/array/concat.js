const filhas = ['Valeskah', 'Cibalena']
const filhos = ['Uoxiton', 'Ueslei']
const todos = filhas.concat(filhos, 'Fulano')
console.log(todos, filhas, filhos)