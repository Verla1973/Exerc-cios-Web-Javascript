for (let i = 0; i < 10; i++){
    console.log(i)
}
console.log('i = ', i)//vai gerar erro por motivo de escopo