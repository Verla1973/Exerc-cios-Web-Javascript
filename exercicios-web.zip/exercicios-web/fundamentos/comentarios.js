console.log("Linha 1")//comentário de uma linha
/*
comentário
de 
múltiplas
linhas
*/
console.log("Linha 2")