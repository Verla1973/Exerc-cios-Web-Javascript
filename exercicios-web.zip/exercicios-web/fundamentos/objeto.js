const prod1 = {}
prod1.nome = 'Celular Ultra Mega'
prod1.preco = 4999.98
prod1['Desconto legal'] = 8.48 //evitar atributos com espaço

console.log(prod1)

const prod2 = {
    nome: 'Camisa Polo',
    preco : 79.90,

}

console.log(prod2)