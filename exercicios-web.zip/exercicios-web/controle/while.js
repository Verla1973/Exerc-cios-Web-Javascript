function geInteiroAleatorio(min, max) {
    const valor = Math.random() * (max - min) + min
    return Math.floor(valor)
}

let opcao = 0

while (opcao != -1) {
    opcao = geInteiroAleatorio(-1, 20)
    console.log(`Opção escolhida foi ${opcao},`)
}

console.log('Até a próxima...')