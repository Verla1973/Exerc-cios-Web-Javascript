let contador = 0
while(contador <= 15) {
    console.log(`Contador = ${contador}`)
    contador++
}

for(let i = 0; i <= 15; i++) {
    console.log(`i = ${i}`)
}

const notas = [6.7, 7.4, 9.8, 6.7, 7.1]
for(let i = 0; i < notas.length; i++) {
    console.log(`Nota = ${notas[i]}`)
}