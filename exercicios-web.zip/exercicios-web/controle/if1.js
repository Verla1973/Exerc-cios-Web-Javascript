function soBoaNoticia(nota) {
    if(nota >= 7){
        console.log('Aprovado com ' + nota)
}else {
        console.log('Reprovado com...'+ nota)
}
}

soBoaNoticia(8.1)
soBoaNoticia(6.1)

function seForVerdadeeuFalo(valor) {
    if(valor) {
        console.log('É verdade...' + valor)
    }
}

seForVerdadeeuFalo()
seForVerdadeeuFalo(null)
seForVerdadeeuFalo(undefined)
seForVerdadeeuFalo(-1)
seForVerdadeeuFalo(' ')
seForVerdadeeuFalo('?')
seForVerdadeeuFalo([])
seForVerdadeeuFalo({})